# Autocompletion Sample

## Installation

1.Execute `npm install` to set up server running environment. 
2.Go to public/ and execute `npm install` to set up client side running enviroment. 

## Usage

1.Go to root directory, execute "npm start".
2.Open browser with url `http://localhost:3000`.


##note

grunt need to be installed globally for build scripts and css.

For windows environment, karma need to be installed globally and package.json need to be modified accordingly for unit test.


